
    <?php
    
        $conn =mysqli_connect('localhost',"mojtaba","test123","saveform");
        if (!$conn) {
            # code...
            echo 'connection error '. mysqli_connect_error();
        }

    
    ?>
